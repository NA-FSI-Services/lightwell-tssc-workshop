"""Workshop Lightwell PyPI Remediated marker (seeded mirror)."""
__version__ = "1.0.0.rhlw-00001"
